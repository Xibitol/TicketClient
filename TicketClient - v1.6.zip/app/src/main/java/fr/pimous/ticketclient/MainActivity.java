package fr.pimous.ticketclient;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.DialogFragment;

import java.util.ArrayList;
import java.util.Collections;

import fr.pimous.ticketclient.dialog.DeleteTicketDialog;
import fr.pimous.ticketclient.ticket.Ticket;
import fr.pimous.ticketclient.ticket.TicketIdComparator;
import fr.pimous.ticketclient.ticket.TicketManager;
import fr.pimous.ticketclient.ticket.exeption.NoTicketWithThisId;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static TicketManager TICKET_MANAGER = new TicketManager();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<Ticket> tickets = TICKET_MANAGER.getListOfTicket();
        Collections.sort(tickets, new TicketIdComparator());
        Collections.reverse(tickets);
        for(Ticket t : tickets){
            addTicketView(t);
        }
    }
    @Override
    public void onBackPressed() {
        return;
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.addTicket:
                Intent ca = new Intent(MainActivity.this, CreateActivity.class);
                startActivity(ca);
                finish();
                return true;
            case R.id.settings:
                Intent sa = new Intent(MainActivity.this, SettingActivity.class);
                startActivity(sa);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    // Init
    public void addTicketView(Ticket t){
        ViewGroup list = findViewById(R.id.list);

        // Principal container
        LinearLayout tContainer = new LinearLayout(this);
        tContainer.setOrientation(LinearLayout.VERTICAL);
        tContainer.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dpConverter(100)));
        ViewGroup.MarginLayoutParams s = (ViewGroup.MarginLayoutParams) tContainer.getLayoutParams();
        s.setMargins(0, dpConverter(10), 0, 0);
        tContainer.setLayoutParams(s);
        tContainer.setBackground(getResources().getDrawable(R.drawable.shape_ticket));

        // Top container
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dpConverter(50)));
        tContainer.addView(top, 0);

        /* id */
        TextView id = new TextView(this);
        id.setLayoutParams(new LinearLayout.LayoutParams(0, 0, 0f));
        id.setText(String.valueOf(t.getId()));
        id.setVisibility(View.INVISIBLE);
        top.addView(id, 0);
        /* number */
        TextView number = new TextView(this);
        number.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT));
        number.setGravity(Gravity.CENTER_VERTICAL);
        number.setPadding(dpConverter(25),0, 0,0);
        number.setText(String.valueOf(t.getNumber()));
        number.setTextSize(24f);
        number.setOnClickListener(this);
        top.addView(number, 1);
        /* type */
        TextView type = new TextView(this);
        type.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        type.setGravity(Gravity.CENTER_VERTICAL);
        type.setPadding(dpConverter(15),0, dpConverter(25),0);
        type.setText(t.getType().getClass().getSimpleName());
        type.setTextSize(24f);
        type.setOnClickListener(this);
        top.addView(type, 2);
        /* isFinished */
        Switch finished = new Switch(this);
        finished.setLayoutParams(new LinearLayout.LayoutParams(dpConverter(78), LinearLayout.LayoutParams.MATCH_PARENT));
        finished.setPadding(0,0,dpConverter(25),0);
        finished.setOnClickListener(this);
        top.addView(finished, 3);

        // Bottom container
        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dpConverter(50)));
        tContainer.addView(bottom, 1);
        /* Name */
        TextView name = new TextView(this);
        name.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        name.setGravity(Gravity.CENTER_VERTICAL);
        name.setPadding(dpConverter(25),0,dpConverter(25),0);
        name.setText(t.getName());
        name.setTextSize(18f);
        name.setOnClickListener(this);
        bottom.addView(name, 0);
        /* call */
        ImageView call = new ImageView(this);
        call.setLayoutParams(new LinearLayout.LayoutParams(dpConverter(75), LinearLayout.LayoutParams.MATCH_PARENT));
        call.setPadding(0,dpConverter(5),dpConverter(25),dpConverter(5));
        call.setImageDrawable(getResources().getDrawable(R.drawable.call_icon));
        call.setContentDescription(getResources().getString(R.string.call));
        call.setOnClickListener(this);
        bottom.addView(call, 1);

        // Add ticket to list
        list.addView(tContainer);
    }

    // On click
    @Override
    public void onClick(View v) {
        switch (v.getClass().getSimpleName()){
            case "Switch":
                deleteTicket(v);
                break;
            case "ImageView":
                call(v);
                break;
            case "TextView":
                viewTicket(v);
                break;
        }
    }
    public void deleteTicket(View v) {
        ViewGroup main = (ViewGroup) v.getParent().getParent();
        ViewGroup container1 = (ViewGroup) main.getChildAt(0);

        DialogFragment df = new DeleteTicketDialog(Integer.parseInt(((TextView) container1.getChildAt(0)).getText().toString()));
        df.show(getSupportFragmentManager(), "delete_ticket");
    }
    public void call(View v){
        TextView id = (TextView) ((ViewGroup) ((ViewGroup) v.getParent().getParent()).getChildAt(0)).getChildAt(0);

        Intent callIntent = new Intent(Intent.ACTION_CALL);
        Ticket t;
        try {
            t = TICKET_MANAGER.findTicketById(id.getText().toString());

            callIntent.setData(Uri.parse("tel:" + t.getPhone()));
        } catch (NoTicketWithThisId ignored) {}

        if(ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) return;
        startActivity(callIntent);
    }
    public void viewTicket(View v){
        TextView id = (TextView) ((ViewGroup) ((ViewGroup) v.getParent().getParent()).getChildAt(0)).getChildAt(0);;

        Intent i = new Intent(MainActivity.this, ViewActivity.class);
        i.putExtra("ticket", id.getText().toString());
        startActivity(i);
        finish();
    }
    
    // Utils
    public int dpConverter(int dp){ return (int) getResources().getDisplayMetrics().density * dp; }
}
