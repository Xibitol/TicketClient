package fr.pimous.ticketclient.ticket;

import android.os.Build;

import androidx.annotation.RequiresApi;

import java.io.File;
import java.util.Comparator;

public class TicketFileIdComparator implements Comparator<File> {

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public int compare(File f1, File f2) {
        int f1FileId = Integer.parseInt((f1.getName().split("_"))[0]);
        int f2FileId = Integer.parseInt((f2.getName().split("_"))[0]);
        return Integer.compare(f1FileId, f2FileId);
    }
}
