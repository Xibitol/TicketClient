package fr.pimous.ticketclient.ticket;

import android.os.Build;

import androidx.annotation.RequiresApi;

import java.util.Comparator;

public class TicketIdComparator implements Comparator<Ticket> {

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public int compare(Ticket f1, Ticket f2) {
        return Integer.compare(f1.getId(), f2.getId());
    }
}
