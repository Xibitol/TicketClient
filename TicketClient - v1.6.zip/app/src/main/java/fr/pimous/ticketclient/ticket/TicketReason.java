package fr.pimous.ticketclient.ticket;

public class TicketReason {

    protected boolean cleaning;
    protected boolean installation;
    protected boolean reparation;

    public TicketReason(boolean cleaning, boolean installation, boolean reparation){
        this.cleaning = cleaning;
        this.installation = installation;
        this.reparation = reparation;
    }

    public boolean isCleaning() { return cleaning; }
    public boolean isInstallation() { return installation; }
    public boolean isReparation() { return reparation; }

    @Override
    public String toString() {
        return "cleaning=" + cleaning + "/installation=" + installation + "/reparation=" + reparation;
    }
}
