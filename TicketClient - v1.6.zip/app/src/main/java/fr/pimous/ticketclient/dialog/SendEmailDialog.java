package fr.pimous.ticketclient.dialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;
import androidx.fragment.app.DialogFragment;

import java.io.File;

import fr.pimous.ticketclient.R;
import fr.pimous.ticketclient.ticket.Ticket;
import fr.pimous.ticketclient.ticket.TicketManager;
import fr.pimous.ticketclient.ticket.exeption.TicketSaverNotInitialized;
import fr.pimous.ticketclient.ticket.types.Notebook;
import fr.pimous.ticketclient.ticket.types.PC;
import fr.pimous.ticketclient.ticket.types.Printer;
import fr.pimous.ticketclient.ticket.types.Tablet;

public class SendEmailDialog extends DialogFragment {

    private Ticket ticket;

    private static TicketManager TICKET_MANAGER = new TicketManager();

    public SendEmailDialog(Ticket t){
        this.ticket = t;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(R.string.email_send);
        builder.setIcon(R.drawable.emailo_icon);
        builder.setMessage(getResources().getString(R.string.email_msg, TICKET_MANAGER.getEmail()));
        builder.setPositiveButton(R.string.send, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("message/rfc822");
                i.putExtra(Intent.EXTRA_EMAIL  , new String[]{TICKET_MANAGER.getEmail()});
                i.putExtra(Intent.EXTRA_SUBJECT, "TicketClient : " + ticket.getName());
                try {
                    File image = new File(TICKET_MANAGER.getTicketSaver().getPicturesDirectory(), ticket.getId() + ".jpg");
                    i.putExtra(Intent.EXTRA_STREAM, FileProvider.getUriForFile(getActivity(), "fr.pimous.ticketclient.pictures", image));
                }catch(TicketSaverNotInitialized ignored){}

                // Email Content
                String text = "";
                text = text + "Actual Id : " + ticket.getId() + "\n";
                text = text + "Name : " + ticket.getName() + "\n";
                text = text + "Phone : " + ticket.getPhone() + "\n";
                text = text + "Type : " + ticket.getType().getClass().getSimpleName() + "\n";
                // Object
                text = text + "   Object ---" + "\n";
                if(ticket.getType().asDoc()) text = text + "        Doc" + "\n";
                if(ticket.getType().asPower()) text = text + "        Power" + "\n";
                switch (ticket.getType().getClass().getSimpleName()){
                    case "PC":
                        if(((PC) ticket.getType()).asSensor()) text = text + "        Sensor" + "\n";
                        break;
                    case "Notebook":
                        if(((Notebook) ticket.getType()).asSensor()) text = text + "        Sensor" + "\n";
                        if(((Notebook) ticket.getType()).asBattery()) text = text + "        Battery" + "\n";
                        break;
                    case "Tablet":
                        if(((Tablet) ticket.getType()).asHolder()) text = text + "        Holder" + "\n";
                        break;
                    case "Printer":
                        if(((Printer) ticket.getType()).asUSB()) text = text + "        USB" + "\n";
                        break;
                }
                // Reason
                text = text + "\n   Reason ---" + "\n";
                if(ticket.getReason().isCleaning()) text = text + "        Cleaning" + "\n";
                if(ticket.getReason().isInstallation()) text = text + "        Installation" + "\n";
                if(ticket.getReason().isReparation()) text = text + "        Reparation" + "\n";
                // Other and put Extra in content
                text = text + "More information : " + ticket.getMoreInformation() + "\n";
                i.putExtra(Intent.EXTRA_TEXT, text);

                try {
                    startActivity(Intent.createChooser(i, "Send mail"));
                } catch (android.content.ActivityNotFoundException ignored) {}
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });
        return builder.create();
    }
}
