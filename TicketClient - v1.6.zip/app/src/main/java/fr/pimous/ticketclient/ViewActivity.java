package fr.pimous.ticketclient;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.DialogFragment;

import com.google.android.material.chip.ChipGroup;

import org.json.JSONException;

import java.io.File;
import java.io.IOException;

import fr.pimous.ticketclient.dialog.DeleteTicketDialog;
import fr.pimous.ticketclient.ticket.Ticket;
import fr.pimous.ticketclient.ticket.TicketManager;
import fr.pimous.ticketclient.ticket.exeption.NoTicketWithThisId;
import fr.pimous.ticketclient.ticket.exeption.TicketSaverNotInitialized;
import fr.pimous.ticketclient.ticket.types.Notebook;
import fr.pimous.ticketclient.ticket.types.PC;
import fr.pimous.ticketclient.ticket.types.Printer;
import fr.pimous.ticketclient.ticket.types.Tablet;

public class ViewActivity extends AppCompatActivity {

    protected Ticket ticket;

    protected EditText numberET;
    protected EditText nameET;
    protected EditText phoneET;
    protected RadioButton typeRB;
    protected ChipGroup paramsObject;
    protected ChipGroup paramsReason;
    protected EditText passwordET;
    protected Switch externalS;
    protected EditText moreInformationET;
    protected ImageView iv;
    protected File picture;
    protected File tempPicture;

    protected TicketManager TICKET_MANAGER = new TicketManager();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        try {
            ticket = TICKET_MANAGER.findTicketById(getIntent().getStringExtra("ticket"));
        } catch (NoTicketWithThisId ignored) {}

        numberET = findViewById(R.id.number);
        nameET = findViewById(R.id.name);
        phoneET = findViewById(R.id.num);
        typeRB = findViewById(R.id.type);
        paramsObject = findViewById(R.id.object);
        paramsReason = findViewById(R.id.reason);
        passwordET = findViewById(R.id.password);
        externalS = findViewById(R.id.external);
        moreInformationET = findViewById(R.id.moreInformation);
        iv = findViewById(R.id.image);

        setTicket();
    }
    @Override
    public void onBackPressed() {
        Intent i = new Intent(ViewActivity.this, MainActivity.class);
        startActivity(i);
        finish();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_view, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.call:
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:" + ticket.getPhone()));

                if(ActivityCompat.checkSelfPermission(ViewActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) return false;
                startActivity(callIntent);
                return true;
            case R.id.message:
                Intent messageIntent = new Intent(Intent.ACTION_SENDTO);
                messageIntent.setData(Uri.parse("smsto:" + ticket.getPhone()));
                messageIntent.putExtra("sms_body", "AD-micro : Bonjour, ");

                startActivity(messageIntent);

                return true;
            case R.id.email:
                /*DialogFragment df = new SendEmailDialogFragment(ticket);
                df.show(getSupportFragmentManager(), "send_email");*/

                Toast.makeText(this, getResources().getString(R.string.available_feature), Toast.LENGTH_LONG).show();
                return true;
            case R.id.delete:
                DialogFragment df = new DeleteTicketDialog(ticket.getId());
                df.show(getSupportFragmentManager(), "delete_ticket");
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    // Set ticket
    public void setTicket(){
        numberET.setText(String.valueOf(ticket.getNumber()));
        nameET.setText(ticket.getName());
        phoneET.setText(ticket.getPhone());
        typeRB.setText(ticket.getType().getClass().getSimpleName());

        switch(ticket.getType().getClass().getSimpleName()){
            case "PC":
                paramsObject.removeViewAt(5);
                paramsObject.removeViewAt(4);
                paramsObject.removeViewAt(3);
                if(!((PC) ticket.getType()).asSensor()) paramsObject.removeViewAt(2);
                break;
            case "Notebook":
                paramsObject.removeViewAt(5);
                paramsObject.removeViewAt(4);
                if(!((Notebook) ticket.getType()).asBattery()) paramsObject.removeViewAt(3);
                if(!((Notebook) ticket.getType()).asSensor()) paramsObject.removeViewAt(2);
                break;
            case "Tablet":
                paramsObject.removeViewAt(5);
                if(!((Tablet) ticket.getType()).asHolder()) paramsObject.removeViewAt(4);
                paramsObject.removeViewAt(3);
                paramsObject.removeViewAt(2);
                break;
            case "Printer":
                if(!((Printer) ticket.getType()).asUSB()) paramsObject.removeViewAt(5);
                paramsObject.removeViewAt(4);
                paramsObject.removeViewAt(3);
                paramsObject.removeViewAt(2);
                break;
            default:
                Toast.makeText(this, getResources().getString(R.string.type_error), Toast.LENGTH_LONG).show();
                return;
        }
        if(!ticket.getType().asDoc()) paramsObject.removeViewAt(1);
        if(!ticket.getType().asPower()) paramsObject.removeViewAt(0);
        if(paramsObject.getChildCount() == 0) ((ViewGroup) paramsObject.getParent()).removeViewAt(0);

        if(!ticket.getReason().isCleaning()) paramsReason.removeViewAt(2);
        if(!ticket.getReason().isInstallation()) paramsReason.removeViewAt(1);
        if(!ticket.getReason().isReparation()) paramsReason.removeViewAt(0);
        if(paramsReason.getChildCount() == 0){
            if(((ViewGroup) paramsReason.getParent()).getChildCount() == 3) ((ViewGroup) paramsReason.getParent()).removeViewAt(1);
            else ((ViewGroup) paramsReason.getParent()).removeViewAt(2);
        }

        if(!ticket.getPassword().isEmpty()) passwordET.setText(ticket.getPassword());
        if(!ticket.getExternal()) ((ViewGroup) externalS.getParent()).removeView(externalS);
        moreInformationET.setText(ticket.getMoreInformation());
        if(ticket.getImage() != null) {
            iv.setImageBitmap(BitmapFactory.decodeFile(ticket.getImage().getPath()));
            picture = ticket.getImage();
        }
    }

    // Image
    public void takePicture(View v) {
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (i.resolveActivity(getPackageManager()) != null) {
            try {
                tempPicture = TICKET_MANAGER.getTicketSaver().createTempPictureFile();
                Uri fileProvider = FileProvider.getUriForFile(this, "fr.pimous.ticketclient", tempPicture);
                i.putExtra(MediaStore.EXTRA_OUTPUT, fileProvider);
                startActivityForResult(i, 0);
            } catch (IOException | TicketSaverNotInitialized e) {
                e.printStackTrace();
            }
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 0 && resultCode == RESULT_OK) {
            try {
                picture = TICKET_MANAGER.getTicketSaver().createPictureFile(ticket.getId(), tempPicture);
            } catch (IOException | TicketSaverNotInitialized ignored) {}
            iv.setImageBitmap(BitmapFactory.decodeFile(picture.getPath()));
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
    public void seePicture(View v) {
        if(ticket.getImage() == null) return;

        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(FileProvider.getUriForFile(this, "fr.pimous.ticketclient", picture),"image/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        i.addFlags(Intent.FLAG_ACTIVITY_NO_USER_ACTION);
        startActivity(i);
    }

    // On click
    public void saveTicket(View v) {
        ticket.setPassword(passwordET.getText().toString());
        ticket.setMoreInformation(moreInformationET.getText().toString());
        ticket.setImage(picture);

        try {
            TICKET_MANAGER.getTicketSaver().deleteTicket(ticket);
            TICKET_MANAGER.getTicketSaver().saveTicket(ticket);
        } catch (TicketSaverNotInitialized | IOException | JSONException e) { }

        Intent i = new Intent(ViewActivity.this, MainActivity.class);
        startActivity(i);
        finish();
    }
}
