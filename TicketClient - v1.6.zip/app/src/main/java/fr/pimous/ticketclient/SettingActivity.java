package fr.pimous.ticketclient;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import fr.pimous.ticketclient.ticket.Ticket;
import fr.pimous.ticketclient.ticket.TicketManager;

public class SettingActivity extends AppCompatActivity {

    protected Ticket ticket;
    protected EditText emailET;
    protected TextView numberTicketEV;

    protected static TicketManager TICKET_MANAGER = new TicketManager();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        emailET = findViewById(R.id.email);
        numberTicketEV = findViewById(R.id.numberTicket);
        if(!TICKET_MANAGER.isFirstLaunch()) emailET.setText(TICKET_MANAGER.getEmail());
        if(TICKET_MANAGER.isFirstLaunch()) {
            ((ViewGroup) numberTicketEV.getParent()).removeView(numberTicketEV);
        }else{
            numberTicketEV.setText(getResources().getString(R.string.ticket_number, TICKET_MANAGER.getTicketNumber()));
        }
    }
    @Override
    public void onBackPressed() {
        Intent i = new Intent(SettingActivity.this, MainActivity.class);
        startActivity(i);
        finish();
    }

    // On click
    public void saveSetting(View v) {
        if(emailET.getText().toString().equals("")){
            Toast.makeText(this, getResources().getString(R.string.email_empty), Toast.LENGTH_LONG).show();
            return;
        }
        else if(!emailET.getText().toString().contains("@")){
            Toast.makeText(this, getResources().getString(R.string.email_mandatory_letter), Toast.LENGTH_LONG).show();
            return;
        }
        TICKET_MANAGER.setEmail(emailET.getText().toString());

        Intent i = new Intent(SettingActivity.this, MainActivity.class);
        startActivity(i);
        finish();
    }
}