package fr.pimous.ticketclient.ticket.types;

public abstract class TicketType {

    // All
    protected boolean power; // <- variable
    public boolean asPower(){ return power; }
    protected boolean doc; // <- variable
    public boolean asDoc(){ return doc; }

    // Pc and Notebook
    protected boolean sensor; // <- variable

    // Notebook
    protected boolean battery; // <- variable

    // Tablet
    protected boolean holder; // <- variable

    // Printer
    protected boolean USB; // <- variable

    public abstract String toString();
}
