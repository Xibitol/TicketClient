package fr.pimous.ticketclient.ticket;

import android.util.Log;

import java.io.File;
import java.io.IOException;

import fr.pimous.ticketclient.ticket.exeption.TicketSaverNotInitialized;
import fr.pimous.ticketclient.ticket.types.TicketType;

public class Ticket {

    protected int id;
    protected int number = -1;
    protected String name;
    protected String phone;
    protected TicketType type;
    protected TicketReason reason;
    protected String password;
    protected boolean external;
    protected String moreInformation;
    protected File image;


    protected static TicketManager TICKET_MANAGER = new TicketManager();

    public Ticket(String name, String phone, TicketType type, TicketReason reason, String password, boolean external, String moreInformation, File image){ // Create constructor
        this(-1, name, phone, type, reason, password, external, moreInformation, image);
    }
    public Ticket(int number, String name, String phone, TicketType type, TicketReason reason, String password, boolean external, String moreInformation, File image){ // Create constructor
        if(number < 0) {
            this.number = TICKET_MANAGER.getTicketNumber();
            TICKET_MANAGER.setTicketNumber(TICKET_MANAGER.getTicketNumber() + 1);
        }
        else{
            this.number = number;
        }

        this.id = TICKET_MANAGER.getIdTickets();
        this.name = name;
        this.phone = phone;
        this.type = type;
        this.reason = reason;
        this.password = password;
        this.external = external;
        this.moreInformation = moreInformation;
        if(image == null)
            try {
                TICKET_MANAGER.getTicketSaver().createPictureFile(this.id, TICKET_MANAGER.getTicketSaver().createTempPictureFile());
            } catch (TicketSaverNotInitialized | IOException e) {}
        else
            this.image = image;

        TICKET_MANAGER.idTicketsUp();
        TICKET_MANAGER.add(this);

        Log.i("Ticket", "NEW TICKET | " + this.toString());
    }

    // Getter
    public int getId(){ return id; }
    public int getNumber(){ return number; }
    public String getName(){ return name; }
    public String getPhone(){ return phone; }
    public TicketType getType(){ return type; }
    public TicketReason getReason() { return reason; }
    public String getPassword(){ return password; }
    public boolean getExternal(){ return external; }
    public String getMoreInformation(){ return moreInformation; }
    public File getImage(){ return image; }

    // Setter
    public void setPassword(String password){
        this.password = password;
    }
    public void setMoreInformation(String moreInformation){
        this.moreInformation = moreInformation;
    }
    public void setImage(File image){ this.image = image; }

    // List
    public void remove(){ TICKET_MANAGER.remove(this); }

    @Override
    public String toString(){
        return "Ticket: id=" + id + "/number=" + number + "/name=" + name + "/num=" + phone + "/type=" + type.toString() + "/reason=" + reason.toString() + "/moreInformation=" + moreInformation + "/password=" + password + "/external=" + external;
    }
}
