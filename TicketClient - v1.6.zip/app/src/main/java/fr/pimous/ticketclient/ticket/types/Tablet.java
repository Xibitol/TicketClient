package fr.pimous.ticketclient.ticket.types;

public class Tablet extends TicketType {

    public Tablet(boolean power, boolean doc, boolean holder){
        super.power = power;
        super.doc = doc;
        super.holder = holder;
    }

    public boolean asHolder(){
        return super.holder;
    }

    @Override
    public String toString() {
        return "PC: power=" + super.asPower() + "/doc=" + super.asDoc() + "/holder=" + asHolder();
    }
}
