package fr.pimous.ticketclient.ticket.exeption;

public class NoTicketWithThisId extends Exception{
    public NoTicketWithThisId(){
        System.out.println("The id you gave must be probably too high. Error: Not ticket has this id");
    }

    @Override
    public String getMessage() {
        return "The id you gave must be probably too high. Error: Not ticket has this id";
    }
}
