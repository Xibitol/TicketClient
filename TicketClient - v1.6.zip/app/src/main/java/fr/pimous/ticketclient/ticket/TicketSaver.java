package fr.pimous.ticketclient.ticket;

import android.app.Activity;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

import fr.pimous.ticketclient.ticket.types.Notebook;
import fr.pimous.ticketclient.ticket.types.PC;
import fr.pimous.ticketclient.ticket.types.Printer;
import fr.pimous.ticketclient.ticket.types.Tablet;
import fr.pimous.ticketclient.ticket.types.TicketType;

public class TicketSaver{

    private final File filesDirectory;
    private final File ticketDirectory;
    private final File picturesDirectory;
    private final File tempPicturesDirectory;

    private static TicketManager TICKET_MANAGER = new TicketManager();

    public TicketSaver(Activity ac){
        String externalFilesDir = ac.getExternalFilesDir(null).getPath();
        String externalCacheDir = ac.getExternalCacheDir().getPath();

        filesDirectory = new File(externalFilesDir);

        ticketDirectory = new File(externalFilesDir + "/Tickets");
        ticketDirectory.mkdir();

        picturesDirectory = new File(externalFilesDir + "/Pictures");
        picturesDirectory.mkdir();

        tempPicturesDirectory = new File(externalCacheDir + "/Pictures");
        tempPicturesDirectory.mkdir();

        try {
            File config = new File(getFilesDirectory(), "config.json");
            if(config.createNewFile()){
                TICKET_MANAGER.setEmail("");
                TICKET_MANAGER.setFirstLaunch(true);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Getter
    public File getFilesDirectory() {
        return filesDirectory;
    }
    public File getTicketsDirectory() {
        return ticketDirectory;
    }
    public File getPicturesDirectory() {
        return picturesDirectory;
    }
    public File getTempPicturesDirectory() {
        return tempPicturesDirectory;
    }
    public File[] sort(File[] files) {
        TicketFileIdComparator tFIC = new TicketFileIdComparator();
        Arrays.sort(files, tFIC);
        return files;
    }

    // Loading
    public void loadTickets() throws IOException, JSONException {
        for (File file : sort(getTicketsDirectory().listFiles())) {
            Log.d("Ticket", file.getName());

            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8));
            String msg = br.readLine();
            br.close();

            JSONObject jo = new JSONObject(msg);

            // Base
            String name = (String) jo.get("name");
            int number = (int) jo.get("number");
            String phone = (String) jo.get("phone");
            String moreInformation = (String) jo.get("moreInformation");
            String password = (String) jo.get("password");
            boolean external = (boolean) jo.get("external");

            // Type
            TicketType tt;
            boolean power = (boolean) jo.get("power");
            boolean doc = (boolean) jo.get("doc");
            switch ((String) jo.get("type")){
                case "PC":
                    boolean sensor1 = (boolean) jo.get("sensor");
                    tt = new PC(power, doc, sensor1);
                    break;
                case "Notebook":
                    boolean sensor2 = (boolean) jo.get("sensor");
                    boolean battery = (boolean) jo.get("battery");
                    tt = new Notebook(power, doc, sensor2, battery);
                    break;
                case "Tablet":
                    boolean holder = (boolean) jo.get("holder");
                    tt = new Tablet(power, doc, holder);
                    break;
                case "Printer":
                    boolean USB = (boolean) jo.get("USB");
                    tt = new Printer(power, doc, USB);
                    break;
                default:
                    throw new IllegalStateException("Unexpected value: " + jo.get("type"));
            }

            // Reason
            boolean cleaning = (boolean) jo.get("cleaning");
            boolean installation = (boolean) jo.get("installation");
            boolean reparation = (boolean) jo.get("reparation");
            TicketReason tr = new TicketReason(cleaning, installation, reparation);

            new Ticket(number, name, phone, tt, tr, password, external, moreInformation, new File(getPicturesDirectory(), TICKET_MANAGER.getIdTickets() + "_picture.jpg"));
        }
    }
    public void loadConfig() throws IOException, JSONException {
        File file = new File(getFilesDirectory(), "config.json");
        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8));
        String msg = br.readLine();
        br.close();

        JSONObject jo = new JSONObject(msg);
        TICKET_MANAGER.setTicketNumber((int) jo.get("ticketNumber"));
        TICKET_MANAGER.setEmail((String) jo.get("email"));
        TICKET_MANAGER.setFirstLaunch((boolean) jo.get("firstLaunch"));
    }

    // Rename File
    public void renameAllTicketsFiles(){
        int id = 0;
        for (File file : sort(getTicketsDirectory().listFiles())) {
            File newFileTicket = new File(getTicketsDirectory(), id + "_ticket.json");
            boolean success = file.renameTo(newFileTicket);

            id++;
        }

        id = 0;
        for (File file : sort(getPicturesDirectory().listFiles())) {
            File newFilePicture = new File(getPicturesDirectory(), id + "_picture.jpg");
            boolean success = file.renameTo(newFilePicture);

            id++;
        }
    }

    // Deleting
    public void deleteTicket(Ticket t){
        File file = new File(getTicketsDirectory(), t.getId() + "_ticket.json");
        file.delete();
    }
    public void deletePicture(int id){
        File file = new File(getPicturesDirectory(), id + "_picture.jpg");
        file.delete();
    }
    public void deletePicture(Ticket t){
        deletePicture(t.getId());
    }

    // Saving
    public void saveTicket(Ticket t) throws IOException, JSONException {
        JSONObject jo = new JSONObject();

        // Base
        jo.put("number", t.getNumber());
        jo.put("name", t.getName());
        jo.put("phone", t.getPhone());
        jo.put("password", t.getPassword());
        jo.put("external", t.getExternal());
        jo.put("moreInformation", t.getMoreInformation());

        // Type
        jo.put("type", t.getType().getClass().getSimpleName());
        jo.put("power", t.getType().asPower());
        jo.put("doc", t.getType().asDoc());
        switch (t.getType().getClass().getSimpleName()){
            case "PC":
                jo.put("sensor", ((PC) t.getType()).asSensor());
                break;
            case "Notebook":
                jo.put("sensor", ((Notebook) t.getType()).asSensor());
                jo.put("battery", ((Notebook) t.getType()).asBattery());
                break;
            case "Tablet":
                jo.put("holder", ((Tablet) t.getType()).asHolder());
                break;
            case "Printer":
                jo.put("USB", ((Printer) t.getType()).asUSB());
                break;
        }

        // Reason
        jo.put("cleaning", t.getReason().isCleaning());
        jo.put("installation", t.getReason().isInstallation());
        jo.put("reparation", t.getReason().isReparation());

        File file= new File(getTicketsDirectory(), t.getId() + "_ticket.json");
        file.createNewFile();

        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8));
        bw.write(jo.toString());
        bw.close();
    }
    public File createPictureFile(int id, File cacheFile) throws IOException{
        File file = new File(getPicturesDirectory(), id + "_picture.jpg");
        if (!file.createNewFile()) {
            file.delete();
            file.createNewFile();
        }

        BufferedInputStream bis = new BufferedInputStream(new FileInputStream(cacheFile));
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));

        byte[] buf = new byte[8];
        while(bis.read(buf) != -1){
            bos.write(buf);
        }

        bis.close();
        bos.close();

        return file;
    }
    public File createTempPictureFile() throws IOException{
        File file = new File(getTempPicturesDirectory(), "picture.jpg");
        if (!file.createNewFile()) {
            file.delete();
            file.createNewFile();
        }
        return file;
    }
    public void saveConfig() throws IOException, JSONException {
        File file = new File(getFilesDirectory(), "config.json");
        if(!file.createNewFile()) {
            file.delete();
            file.createNewFile();
        }

        JSONObject jo = new JSONObject();
        jo.put("ticketNumber", TICKET_MANAGER.getTicketNumber());
        jo.put("email", TICKET_MANAGER.getEmail());
        jo.put("firstLaunch", TICKET_MANAGER.isFirstLaunch());

        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8));
        bw.write(jo.toString());
        bw.close();
    }
}
