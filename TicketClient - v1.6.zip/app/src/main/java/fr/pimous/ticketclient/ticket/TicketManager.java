package fr.pimous.ticketclient.ticket;

import android.app.Activity;

import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;

import fr.pimous.ticketclient.ticket.exeption.NoTicketWithThisId;
import fr.pimous.ticketclient.ticket.exeption.TicketSaverNotInitialized;

public class TicketManager {

    protected static TicketSaver SAVER;
    protected static ArrayList<Ticket> LIST_OF_TICKET = new ArrayList<>();
    protected static int ID_TICKETS = 0;
    protected static int TICKET_NUMBER = 0;

    // Config
    protected static String EMAIL;
    protected static boolean FIRST_LAUNCH;

    public TicketManager(){}
    public TicketManager(Activity ac) {
        SAVER = new TicketSaver(ac);
    }

    // Getter
    public ArrayList<Ticket> getListOfTicket(){ return LIST_OF_TICKET; }
    public TicketSaver getTicketSaver() throws TicketSaverNotInitialized {
        if(SAVER != null) return SAVER;
        throw new TicketSaverNotInitialized();
    }
    public int getIdTickets(){ return ID_TICKETS; }
    public String getEmail(){ return EMAIL; }
    public boolean isFirstLaunch(){ return FIRST_LAUNCH; }
    public int getTicketNumber(){ return TICKET_NUMBER; }

    // Setter
    public void setEmail(String email) {
        EMAIL = email;
        try {
            getTicketSaver().saveConfig();
        } catch (IOException | JSONException | TicketSaverNotInitialized ignored) {}
    }
    public void setFirstLaunch(boolean firstLaunch) {
        FIRST_LAUNCH = firstLaunch;
        try {
            getTicketSaver().saveConfig();
        } catch (IOException | JSONException | TicketSaverNotInitialized ignored) {}
    }
    public void setTicketNumber(int ticketNumber) {
        TICKET_NUMBER = ticketNumber;
        try {
            getTicketSaver().saveConfig();
        } catch (IOException | JSONException | TicketSaverNotInitialized ignored) {}
    }

    // Id Tickets
    public void idTicketsUp(){
        ID_TICKETS++;
    }

    // List
    public Ticket findTicketById(int id) throws NoTicketWithThisId {
        for(Ticket t : LIST_OF_TICKET){
            if(t.getId() == id) return t;
        }
        throw new NoTicketWithThisId();
    }
    public Ticket findTicketById(String idStr) throws NoTicketWithThisId {
        int id = Integer.parseInt(idStr);
        return findTicketById(id);
    }
    public void add(Ticket t) {
        LIST_OF_TICKET.add(t);
    }
    public void remove(Ticket t) {
        LIST_OF_TICKET.remove(t);
    }
}
