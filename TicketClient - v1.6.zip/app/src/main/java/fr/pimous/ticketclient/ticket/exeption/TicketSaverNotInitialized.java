package fr.pimous.ticketclient.ticket.exeption;

public class TicketSaverNotInitialized extends Exception {
    public TicketSaverNotInitialized(){
           System.out.println("Please use \"new TicketManager(Activity ac)\\n\" at least once. Error: Ticket Saver not initialized");
    }

    @Override
    public String getMessage() {
        return "Please use \"new TicketManager(Activity ac)\" at least once. Error: Ticket Saver not initialized";
    }
}