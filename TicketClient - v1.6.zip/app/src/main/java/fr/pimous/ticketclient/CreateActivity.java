package fr.pimous.ticketclient;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import org.json.JSONException;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import fr.pimous.ticketclient.ticket.Ticket;
import fr.pimous.ticketclient.ticket.TicketManager;
import fr.pimous.ticketclient.ticket.TicketReason;
import fr.pimous.ticketclient.ticket.exeption.TicketSaverNotInitialized;
import fr.pimous.ticketclient.ticket.types.Notebook;
import fr.pimous.ticketclient.ticket.types.PC;
import fr.pimous.ticketclient.ticket.types.Printer;
import fr.pimous.ticketclient.ticket.types.Tablet;
import fr.pimous.ticketclient.ticket.types.TicketType;

public class CreateActivity extends AppCompatActivity {

    protected EditText nameET;
    protected EditText phoneET;
    protected RadioGroup typeRG;
    protected LinearLayout paramsType;
    protected EditText passwordET;
    protected Switch externalS;
    protected EditText moreInformationET;
    protected ImageView iv;
    protected TextView imageTV;
    protected File picture;
    protected File tempPicture;

    protected Button createB;

    private static TicketManager TICKET_MANAGER = new TicketManager();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        nameET = findViewById(R.id.name);
        phoneET = findViewById(R.id.num);
        typeRG = findViewById(R.id.typeList);
        passwordET = findViewById(R.id.password);
        externalS = findViewById(R.id.external);
        moreInformationET = findViewById(R.id.moreInformation);
        iv = findViewById(R.id.image);
        imageTV = findViewById(R.id.imageText);
        createB = findViewById(R.id.create);

    }
    @Override
    public void onBackPressed() {
        try {
            TICKET_MANAGER.getTicketSaver().deletePicture(TICKET_MANAGER.getIdTickets());
        } catch (TicketSaverNotInitialized ignored) {}

        Intent i = new Intent(CreateActivity.this, MainActivity.class);
        startActivity(i);
        finish();

        return;
    }

    // Image
    public void takePicture(View v) {
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (i.resolveActivity(getPackageManager()) != null) {
            try {
                tempPicture = TICKET_MANAGER.getTicketSaver().createTempPictureFile();
                Uri fileProvider = FileProvider.getUriForFile(this, "fr.pimous.ticketclient", tempPicture);
                i.putExtra(MediaStore.EXTRA_OUTPUT, fileProvider);
                startActivityForResult(i, 0);
            } catch (IOException | TicketSaverNotInitialized e) {
                e.printStackTrace();
            }
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 0 && resultCode == RESULT_OK) {
            try {
                picture = TICKET_MANAGER.getTicketSaver().createPictureFile(TICKET_MANAGER.getIdTickets(), tempPicture);
            } catch (IOException | TicketSaverNotInitialized ignored) {}
            iv.setImageBitmap(BitmapFactory.decodeFile(picture.getPath()));
            imageTV.setVisibility(View.INVISIBLE);
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    // Open TicketReason section
    public void openTReasonSection(View v){
        if(paramsType != null) paramsType.removeAllViews();

        // Object TextView
        TextView objectText = new TextView(this);
        objectText.setText(getResources().getString(R.string.object));
        objectText.setTextSize(14f);
        objectText.setTextColor(getResources().getColor(R.color.colorPrimary));
        // Object RadioGroup
        ChipGroup object = new ChipGroup(this);
        List<Chip> objectChips = new ArrayList<>();
        List<String> objects = Arrays.asList(
                getResources().getString(R.string.power),
                getResources().getString(R.string.doc),
                getResources().getString(R.string.sensor),
                getResources().getString(R.string.battery),
                getResources().getString(R.string.holder),
                getResources().getString(R.string.USB)
        );
        for(String i : objects){
            Chip chip = new Chip(new ContextThemeWrapper(this, R.style.ChipTheme));
            chip.setText(i);
            chip.setTextSize(14f);
            chip.setTextColor(getResources().getColor(R.color.colorSecondary));
            chip.setCheckedIcon(getResources().getDrawable(R.drawable.checked_icon));
            objectChips.add(chip);
        }

        // Reason TextView
        TextView reasonText = new TextView(this);
        reasonText.setText(getResources().getString(R.string.reason));
        reasonText.setTextSize(14f);
        reasonText.setTextColor(getResources().getColor(R.color.colorPrimary));
        // Reason RadioGroup
        ChipGroup reason = new ChipGroup(this);
        List<String> reasons = Arrays.asList(
                getResources().getString(R.string.cleaning),
                getResources().getString(R.string.installation),
                getResources().getString(R.string.reparation)
        );
        for(String i : reasons){
            Chip chip = new Chip(new ContextThemeWrapper(this, R.style.ChipTheme));
            chip.setText(i);
            chip.setTextSize(14f);
            chip.setTextColor(getResources().getColor(R.color.colorSecondary));
            chip.setCheckedIcon(getResources().getDrawable(R.drawable.checked_icon));
            reason.addView(chip);
        }

        switch (typeRG.getCheckedRadioButtonId()){
            case R.id.pc:
                paramsType = findViewById(R.id.pcparams);
                // Object
                paramsType.addView(objectText, 0);
                paramsType.addView(object, 1);
                object.addView(objectChips.get(0));
                object.addView(objectChips.get(1));
                object.addView(objectChips.get(2));
                // Reason
                paramsType.addView(reasonText, 2);
                paramsType.addView(reason, 3);
                break;
            case R.id.notebook:
                paramsType = findViewById(R.id.notebookparams);
                // Object
                paramsType.addView(objectText, 0);
                paramsType.addView(object, 1);
                object.addView(objectChips.get(0));
                object.addView(objectChips.get(1));
                object.addView(objectChips.get(2));
                object.addView(objectChips.get(3));
                // Reason
                paramsType.addView(reasonText, 2);
                paramsType.addView(reason, 3);
                break;
            case R.id.tablet:
                paramsType = findViewById(R.id.tabletparams);
                // Object
                paramsType.addView(objectText, 0);
                paramsType.addView(object, 1);
                object.addView(objectChips.get(0));
                object.addView(objectChips.get(1));
                object.addView(objectChips.get(4));
                // Reason
                paramsType.addView(reasonText, 2);
                paramsType.addView(reason, 3);
                break;
            case R.id.printer:
                paramsType = findViewById(R.id.printerparams);
                // Object
                paramsType.addView(objectText, 0);
                paramsType.addView(object, 1);
                object.addView(objectChips.get(0));
                object.addView(objectChips.get(1));
                object.addView(objectChips.get(5));
                // Reason
                paramsType.addView(reasonText, 2);
                paramsType.addView(reason, 3);
                break;
            default:
                Toast.makeText(this, getResources().getString(R.string.type_error), Toast.LENGTH_LONG).show();
                return;
        }
    }

    // Create
    public void createTicket(View v){
        if(nameET.getText().toString().isEmpty()) Toast.makeText(this, getResources().getString(R.string.missing_name), Toast.LENGTH_LONG).show();
        else if(phoneET.getText().toString().isEmpty()) Toast.makeText(this, getResources().getString(R.string.missing_phone), Toast.LENGTH_LONG).show();
        else if(typeRG.getCheckedRadioButtonId() == -1) Toast.makeText(this, getResources().getString(R.string.missing_type), Toast.LENGTH_LONG).show();
        else{
            TicketType type;
            Chip power = (Chip) ((ChipGroup) paramsType.getChildAt(1)).getChildAt(0);
            Chip doc = (Chip) ((ChipGroup) paramsType.getChildAt(1)).getChildAt(1);
            Chip sensor = (Chip) ((ChipGroup) paramsType.getChildAt(1)).getChildAt(2);
            switch (typeRG.getCheckedRadioButtonId()){
                case R.id.pc:
                    type = new PC(power.isChecked(), doc.isChecked(), sensor.isChecked());
                    break;
                case R.id.notebook:
                    Chip battery = (Chip) ((ChipGroup) paramsType.getChildAt(1)).getChildAt(3);
                    type = new Notebook(power.isChecked(), doc.isChecked(), sensor.isChecked(), battery.isChecked());
                    break;
                case R.id.tablet:
                    Chip holder = (Chip) ((ChipGroup) paramsType.getChildAt(1)).getChildAt(2);
                    type = new Tablet(power.isChecked(), doc.isChecked(), holder.isChecked());
                    break;
                case R.id.printer:
                    Chip USB = (Chip) ((ChipGroup) paramsType.getChildAt(1)).getChildAt(2);
                    type = new Printer(power.isChecked(), doc.isChecked(), USB.isChecked());
                    break;
                default:
                    Toast.makeText(this, getResources().getString(R.string.type_error), Toast.LENGTH_LONG).show();
                    return;
            }

            Chip cleaning = (Chip) ((ChipGroup) paramsType.getChildAt(3)).getChildAt(0);
            Chip installation = (Chip) ((ChipGroup) paramsType.getChildAt(3)).getChildAt(1);
            Chip reparation = (Chip) ((ChipGroup) paramsType.getChildAt(3)).getChildAt(2);
            TicketReason reason = new TicketReason(cleaning.isChecked(), installation.isChecked(), reparation.isChecked());

            Ticket t = new Ticket(nameET.getText().toString(), phoneET.getText().toString(), type, reason, passwordET.getText().toString(), externalS.isChecked(), moreInformationET.getText().toString(), picture);
            try {
                TICKET_MANAGER.getTicketSaver().saveTicket(t);
            } catch (TicketSaverNotInitialized | IOException | JSONException e) { }

            startActivity(new Intent(CreateActivity.this, MainActivity.class));
            finish();
        }

        return;
    }
}
