package fr.pimous.ticketclient.ticket.types;

public class PC extends TicketType {

    public PC(boolean power, boolean doc, boolean sensor){
        super.power = power;
        super.doc = doc;
        super.sensor = sensor;
    }

    public boolean asSensor(){
        return super.sensor;
    }

    @Override
    public String toString() {
        return "PC: power=" + super.asPower() + "/doc=" + super.asDoc() + "/sensor=" + asSensor();
    }
}
