package fr.pimous.ticketclient.ticket.types;

public class Notebook extends TicketType {

    public Notebook(boolean power, boolean doc, boolean sensor, boolean battery){
        super.power = power;
        super.doc = doc;
        super.sensor = sensor;
        super.battery = battery;
    }

    public boolean asSensor(){
        return super.sensor;
    }
    public boolean asBattery(){
        return super.battery;
    }

    @Override
    public String toString() {
        return "Notebook: power=" + super.asPower() + "/doc=" + super.asDoc() + "/sensor=" + asSensor() + "/battery=" + asBattery();
    }
}