package fr.pimous.ticketclient.ticket.types;

public class Printer extends TicketType {

    public Printer(boolean power, boolean doc, boolean USB){
        super.power = power;
        super.doc = doc;
        super.USB = USB;
    }

    public boolean asUSB(){
        return super.USB;
    }

    @Override
    public String toString() {
        return "PC: power=" + super.asPower() + "/doc=" + super.asDoc() + "/USB=" + asUSB();
    }
}
