package fr.pimous.ticketclient.dialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import fr.pimous.ticketclient.MainActivity;
import fr.pimous.ticketclient.R;
import fr.pimous.ticketclient.ticket.Ticket;
import fr.pimous.ticketclient.ticket.TicketManager;
import fr.pimous.ticketclient.ticket.exeption.NoTicketWithThisId;
import fr.pimous.ticketclient.ticket.exeption.TicketSaverNotInitialized;

public class DeleteTicketDialog extends DialogFragment {

    private Ticket ticket;

    private static TicketManager TICKET_MANAGER = new TicketManager();

    public DeleteTicketDialog(int id){
        try {
            this.ticket = TICKET_MANAGER.findTicketById(id);
        } catch (NoTicketWithThisId noTicketWithThisId) {
            noTicketWithThisId.printStackTrace();
        }
    }

    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(R.string.delete);
        builder.setIcon(R.drawable.delete_icon);
        builder.setMessage(getResources().getString(R.string.delete_msg, ticket.getName(), ticket.getType().getClass().getSimpleName()));
        builder.setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                try {
                    ticket.remove();
                    TICKET_MANAGER.getTicketSaver().deleteTicket(ticket);
                    TICKET_MANAGER.getTicketSaver().deletePicture(ticket);
                } catch (TicketSaverNotInitialized e) {}

                Intent i = new Intent(getActivity(), MainActivity.class);
                startActivity(i);
                getActivity().finish();

                dialog.cancel();
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });
        return builder.create();
    }

    @Override
    public void onCancel(@NonNull DialogInterface dialog) {
        super.onCancel(dialog);
    }
}
