package fr.pimous.ticketclient;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import org.json.JSONException;

import java.io.IOException;

import fr.pimous.ticketclient.ticket.TicketManager;
import fr.pimous.ticketclient.ticket.exeption.TicketSaverNotInitialized;

public class LoadingActivity extends AppCompatActivity {

    private static int TIMER = 1000;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loading);

        final TicketManager TICKET_MANAGER = new TicketManager(this);

        try {
            TICKET_MANAGER.getTicketSaver().renameAllTicketsFiles();

            TICKET_MANAGER.getTicketSaver().loadTickets();
            TICKET_MANAGER.getTicketSaver().loadConfig();
        } catch (TicketSaverNotInitialized | IOException | JSONException ignored) {}

        ActivityCompat.requestPermissions(LoadingActivity.this, new String[] {Manifest.permission.CALL_PHONE}, Toast.LENGTH_SHORT);
        int i = 0;
        while(i != 2) {
            if(ActivityCompat.checkSelfPermission(LoadingActivity.this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED)
                i++;
        }

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if(TICKET_MANAGER.isFirstLaunch()){
                    TICKET_MANAGER.setFirstLaunch(false);

                    Intent i = new Intent(LoadingActivity.this, SettingActivity.class);
                    startActivity(i);
                    finish();
                }else{
                    Intent i = new Intent(LoadingActivity.this, MainActivity.class);
                    startActivity(i);
                    finish();
                }
            }
        }, TIMER);
    }
    @Override
    public void onBackPressed() {
        return;
    }
}
