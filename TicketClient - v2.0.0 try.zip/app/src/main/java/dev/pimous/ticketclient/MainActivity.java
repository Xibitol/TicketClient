package dev.pimous.ticketclient;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.res.ResourcesCompat;

import android.content.Intent;
import android.os.Bundle;
import android.transition.Fade;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import dev.pimous.ticketclient.ticket.Ticket;
import dev.pimous.ticketclient.ticket.TicketNumberComparator;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        List<Ticket> tickets = Ticket.getTickets();
        Collections.sort(tickets, new TicketNumberComparator());
        //Collections.reverse(tickets); // The youngest to the oldest

        ViewGroup ticketsContainer = findViewById(R.id.ticketsContainer);
        for (Ticket ticket : tickets) ticketsContainer.addView(createTicketView(ticket));

        View lastView = ticketsContainer.getChildAt(ticketsContainer.getChildCount() - 1);
        LinearLayout.LayoutParams ll = (LinearLayout.LayoutParams) lastView.getLayoutParams();
        ll.setMargins(TicketClient.dpConverter(10), TicketClient.dpConverter(10), TicketClient.dpConverter(10), TicketClient.dpConverter(10));
        lastView.setLayoutParams(ll);
    }
    @Override
    public void onBackPressed() {
        return;
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.new_ticket){
            Intent i = new Intent(MainActivity.this, CreateActivity.class);
            startActivity(i);
            finish();
            return true;
        } else return super.onOptionsItemSelected(item);
    }

    public View createTicketView(Ticket t){
        LinearLayout container = new LinearLayout(this);
        LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, TicketClient.dpConverter(90));
        ll.setMargins(TicketClient.dpConverter(10), TicketClient.dpConverter(10), TicketClient.dpConverter(10), 0);
        container.setLayoutParams(ll);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setBackgroundResource(R.drawable.shape_ticket);
        container.setElevation(20);

        // Top
        LinearLayout top = new LinearLayout(this);
        top.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        top.setOrientation(LinearLayout.HORIZONTAL);
        container.addView(top);
        /* number */
        TextView number = new TextView(this);
        number.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        number.setGravity(Gravity.CENTER);
        number.setText(String.valueOf(t.getNumber()));
        number.setTextSize(24f);
        top.addView(number);
        /* type */
        TextView type = new TextView(this);
        type.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 3f));
        type.setGravity(Gravity.CENTER_VERTICAL);
        type.setPadding(TicketClient.dpConverter(15),0, 0,0);
        type.setText(t.getDescription().getClass().getSimpleName());
        type.setTextSize(24f);
        type.setTextColor(getResources().getColor(R.color.orange_600));
        top.addView(type);
        /* isFinished */
        FrameLayout finishedContainer = new FrameLayout(this);
        finishedContainer.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        top.addView(finishedContainer);
        SwitchCompat finished = new SwitchCompat(new ContextThemeWrapper(this, R.style.Widget_TicketClient_Switch));
        finished.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        //finished.setOnClickListener(this);
        finishedContainer.addView(finished);

        // Bottom
        LinearLayout bottom = new LinearLayout(this);
        bottom.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        container.addView(bottom);
        /* Name */
        TextView name = new TextView(this);
        name.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 4f));
        name.setGravity(Gravity.CENTER_VERTICAL);
        name.setPadding(TicketClient.dpConverter(20), 0, 0, 0);
        name.setText(t.getName());
        name.setTextSize(18f);
        bottom.addView(name);
        /* call */
        ImageView call = new ImageView(this);
        call.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        call.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.ic_call, null));
        call.setPadding(0, TicketClient.dpConverter(4), 0, TicketClient.dpConverter(4));
        bottom.addView(call);

        return container;
    }
}