package dev.pimous.ticketclient;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Config implements Serializable {

    protected static File config;
    protected static Config instance = new Config();

    // DATA
    protected int ticketsNumber = 0;

    public static int getTicketsNumber(){ return Config.instance.ticketsNumber; }
    public static void addTicket(){
        Config.instance.ticketsNumber++;
        Config.save();
    }

    // FUNCTIONS
    public static void setConfigFile(File file) { Config.config = file; }
    public static void load(){
        try(ObjectInputStream ois = new ObjectInputStream(new BufferedInputStream(new FileInputStream(config)))){
            Config.instance = (Config) ois.readObject();
        } catch (IOException | ClassNotFoundException ignored) {
            Config.save();
        }
    }
    public static void save(){
        try {
            config.delete();
            if(!config.createNewFile()) return;
        } catch (IOException ignored) {}

        try(ObjectOutputStream oos = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(config)))){
            oos.writeObject(instance);
        } catch (IOException ignored) {}
    }
}
