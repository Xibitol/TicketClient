package dev.pimous.ticketclient.ticket;

import org.json.JSONObject;

public class TicketPrice {

    protected int parts;
    protected int workmanship;

    public TicketPrice(int parts, int workmanship){
        this.parts = parts;
        this.workmanship = workmanship;
    }

    public int getParts(){ return parts; }
    public int getWorkmanship(){ return workmanship; }

    public void setPartsPrice(int parts){ this.parts = parts; }
    public void setWorkmanship(int workmanship){ this.workmanship = workmanship; }

    @Override
    public String toString() {
        return "TicketPrice{" +
                "parts=" + parts +
                ", workmanship=" + workmanship +
                '}';
    }
}
