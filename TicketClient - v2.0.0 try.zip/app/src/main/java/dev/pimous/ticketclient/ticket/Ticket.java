package dev.pimous.ticketclient.ticket;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import dev.pimous.ticketclient.Config;

public class Ticket {

    protected static File ticketsFile;
    protected static File picturesDir;
    protected static File tempPicturesDir;
    protected static List<Ticket> tickets = new ArrayList<>();

    protected int number;
    protected String name;
    protected String phone = "";
    protected TicketDescription description; // Multiple
    protected String password = "";
    protected boolean external;
    protected String moreInformation = "";
    protected File image; // Multiple
    protected String result = "";
    protected TicketPrice price = new TicketPrice(0, 0);

    public Ticket(String name, TicketDescription description, boolean external){
        this(-1, name, description, external);
    }
    public Ticket(int number, String name, TicketDescription description, boolean external){
        if(number <= 0) {
            Config.addTicket();
            this.number = Config.getTicketsNumber();
        }else this.number = number;

        this.name = name;
        this.description = description;
        this.external = external;

        tickets.add(this);
    }

    /* ---- GETTERS ---- */
    public static List<Ticket> getTickets(){ return new ArrayList<>(tickets); }
    public static Ticket getTicketByNumber(int number){
        for(Ticket ticket : tickets) if(ticket.getNumber() == number) return ticket;
        return null;
    }

    public int getNumber(){ return number; }
    public String getName(){ return name; }
    public String getPhone(){ return phone; }
    public TicketDescription getDescription(){ return description; }
    public String getPassword(){ return password; }
    public boolean getExternal(){ return external; }
    public String getMoreInformation(){ return moreInformation; }
    public File getImage(){ return image; }
    public String getResult(){ return result; }
    public TicketPrice getPrice(){ return price; }

    /* ---- SETTERS ---- */
    public void remove(){ tickets.remove(this); }

    public void setPhone(String phone){ this.phone = phone; }
    public void setPassword(String password){ this.password = password; }
    public void setMoreInformation(String moreInformation){ this.moreInformation = moreInformation; }
    public void setImage(File image){ this.image = image; }
    public void setResult(String result){ this.result = result; }
    public void setPartsPrice(int parts){ this.price.setPartsPrice(parts); }
    public void setWorkmanshipPrice(int workmanship){ this.price.setWorkmanship(workmanship); }

    /* ---- FUNCTIONS ---- */
    public static void setTicketsFile(File file) { Ticket.ticketsFile = file; }
    public static void setPicturesDir(File directory) { Ticket.picturesDir = directory; }
    public static void setTempPictureDir(File directory) { Ticket.tempPicturesDir = directory; }
    public static void loads() throws JSONException {
        try(BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(ticketsFile), StandardCharsets.UTF_8))){
            JSONArray jsonTickets = new JSONArray(br.readLine());
            for(int i = 0; i < jsonTickets.length(); i++){
                JSONObject jt = jsonTickets.getJSONObject(i);

                TicketDescription td;
                try {
                    JSONObject jd = jt.getJSONObject("description");
                    Class<?> clazz = Class.forName("dev.pimous.ticketclient.ticket.types." + jd.getString("type"));
                    td = (TicketDescription) clazz.newInstance();

                    JSONArray ja = jd.getJSONArray("deposits");
                    for(int j = 0; j < ja.length(); j++)
                        td.addDeposit(TicketDeposit.valueOf(ja.getString(j)));

                    ja = jd.getJSONArray("reasons");
                    for(int j = 0; j < ja.length(); j++)
                        td.addReason(TicketReason.valueOf(ja.getString(j)));
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException ignored) {
                    continue;
                }

                Ticket t = new Ticket(jt.getInt("number"),
                        jt.getString("name"),
                        td,
                        jt.getBoolean("external"));

                t.setPhone(jt.getString("phone"));
                t.setPassword(jt.getString("password"));
                t.setMoreInformation(jt.getString("moreInformation"));
                t.setResult(jt.getString("result"));

                JSONObject jp = jt.getJSONObject("price");
                t.setPartsPrice(jp.getInt("parts"));
                t.setWorkmanshipPrice(jp.getInt("workmanship"));
            }
        } catch (IOException ignored) {}
    }
    public static void saves() throws IOException {
        JSONArray jsonTickets = new JSONArray();
        for (Ticket ticket : tickets) {
            JSONObject jt = new JSONObject();

            try{
                jt.put("number", ticket.getNumber());
                jt.put("name", ticket.getName());
                jt.put("phone", ticket.getPhone());

                JSONObject jd = new JSONObject();
                jd.put("type", ticket.getDescription().getClass().getSimpleName());
                JSONArray jaDeposits = new JSONArray();
                for (TicketDeposit deposit : ticket.getDescription().getDeposits())
                    jaDeposits.put(deposit.name());
                jd.put("deposits", jaDeposits);
                JSONArray jaReasons = new JSONArray();
                for (TicketReason reason : ticket.getDescription().getReasons())
                    jaReasons.put(reason.name());
                jd.put("reasons", jaReasons);
                jt.put("description", jd);

                jt.put("password", ticket.getPassword());
                jt.put("external", ticket.getExternal());
                jt.put("moreInformation", ticket.getMoreInformation());
                jt.put("result", ticket.getResult());

                JSONObject jp = new JSONObject();
                jp.put("parts", ticket.getPrice().getParts());
                jp.put("workmanship", ticket.getPrice().getWorkmanship());
                jt.put("price", jp);
            } catch(JSONException ignored) {}

            jsonTickets.put(jt);
        }

        try {
            ticketsFile.delete();
            if(!ticketsFile.createNewFile()) return;
        } catch (IOException ignored) {}

        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(ticketsFile), StandardCharsets.UTF_8));
        bw.write(jsonTickets.toString());
        bw.close();
    }

    @Override
    public String toString() {
        return "Ticket{" +
                "number=" + number +
                ", name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                ", description=" + description +
                ", password='" + password + '\'' +
                ", external=" + external +
                ", moreInformation='" + moreInformation + '\'' +
                ", result='" + result + '\'' +
                ", price=" + price +
                '}';
    }
}
