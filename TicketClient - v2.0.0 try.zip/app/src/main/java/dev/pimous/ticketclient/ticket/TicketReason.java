package dev.pimous.ticketclient.ticket;

public enum TicketReason {

    CLEANING(),
    INSTALLATION(),
    REINSTALLATION(),
    FULL_REINSTALLATION(),
    REPARATION()
}
