package dev.pimous.ticketclient.ticket.types;

import java.util.Arrays;
import java.util.List;

import dev.pimous.ticketclient.ticket.TicketDeposit;
import dev.pimous.ticketclient.ticket.TicketDescription;

public class Notebook extends TicketDescription {

    @Override
    public List<TicketDeposit> getAuthorizedDeposits() {
        return Arrays.asList(
                TicketDeposit.POWER,
                TicketDeposit.SENSOR,
                TicketDeposit.BATTERY,
                TicketDeposit.HOLDER
        );
    }
}
