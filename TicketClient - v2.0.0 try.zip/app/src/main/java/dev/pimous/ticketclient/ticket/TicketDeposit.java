package dev.pimous.ticketclient.ticket;

public enum TicketDeposit {

    POWER(),
    SENSOR(),
    BATTERY(),
    HOLDER(),
    USB();
}
