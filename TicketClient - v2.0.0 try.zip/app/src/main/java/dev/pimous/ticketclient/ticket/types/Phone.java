package dev.pimous.ticketclient.ticket.types;

import java.util.Collections;
import java.util.List;

import dev.pimous.ticketclient.ticket.TicketDeposit;
import dev.pimous.ticketclient.ticket.TicketDescription;

public class Phone extends TicketDescription {

    @Override
    public List<TicketDeposit> getAuthorizedDeposits() {
        return Collections.singletonList(TicketDeposit.POWER);
    }
}
