package dev.pimous.ticketclient.ticket;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public abstract class TicketDescription {

    protected List<TicketDeposit> deposits = new ArrayList<>();
    protected List<TicketReason> reasons = new ArrayList<>();

    public abstract List<TicketDeposit> getAuthorizedDeposits();
    public List<TicketDeposit> getDeposits(){ return new ArrayList<>(deposits); }
    public List<TicketReason> getAuthorizedReasons(){ return Arrays.asList(TicketReason.values()); }
    public List<TicketReason> getReasons(){ return new ArrayList<>(reasons); }

    public void addDeposit(TicketDeposit deposit){ deposits.add(deposit); }
    public void removeDeposit(TicketDeposit deposit){ deposits.remove(deposit); }
    public void setDeposits(List<TicketDeposit> deposits){ this.deposits = deposits; }

    public void addReason(TicketReason reason){ reasons.add(reason); }
    public void removeReason(TicketReason reason){ reasons.remove(reason); }
    public void setReasons(List<TicketReason> reasons){ this.reasons = reasons; }

    @Override
    public String toString() {
        return "TicketDescription{" +
                "deposits=" + deposits +
                ", reasons=" + reasons +
                '}';
    }
}
