package dev.pimous.ticketclient;

import android.content.Context;
import android.util.Log;

import org.json.JSONException;

import java.io.File;
import java.io.IOException;

import dev.pimous.ticketclient.ticket.Ticket;
import dev.pimous.ticketclient.ticket.TicketDeposit;
import dev.pimous.ticketclient.ticket.TicketReason;
import dev.pimous.ticketclient.ticket.types.Notebook;
import dev.pimous.ticketclient.ticket.types.Printer;

public class TicketClient {

    protected static TicketClient instance;
    protected static float displayDensity;

    public TicketClient(Context context){
        TicketClient.displayDensity = context.getResources().getDisplayMetrics().density;

        Config.setConfigFile(new File(context.getExternalFilesDir(null), "ticketclient.config"));
        Config.load();

        Ticket.setTicketsFile(new File(context.getExternalFilesDir(null), "tickets.json"));
        Ticket.setPicturesDir(new File(context.getExternalFilesDir(null), "Pictures"));
        Ticket.setTempPictureDir(new File(context.getExternalCacheDir(), "Pictures"));
        try {
            Ticket.loads();
        } catch (JSONException ignored) {
            ignored.printStackTrace();
        }

        instance = this;
    }

    public static TicketClient get(){ return instance; }
    public static int dpConverter(int dp){ return (int) displayDensity * dp; }
}
