package dev.pimous.ticketclient.ticket;

import java.util.Comparator;

public class TicketNumberComparator implements Comparator<Ticket> {

    @Override
    public int compare(Ticket t1, Ticket t2) {
        return Integer.compare(t1.getNumber(), t2.getNumber());
    }
}
